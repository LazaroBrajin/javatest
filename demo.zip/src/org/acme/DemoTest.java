package org.acme;

import static org.junit.Assert.*;

import java.util.Map;

import org.junit.Test;

public class DemoTest {

	private Demo demo ;
	
	@Test(expected = Exception.class)
	public void test(boolean logToFileParam, boolean logToConsoleParam, boolean logToDatabaseParam, boolean logMessageParam, boolean logWarningParam, boolean logErrorParam, Map dbParamsMap) throws Exception {
		new Demo(logToFileParam, logToConsoleParam, logToDatabaseParam, logMessageParam, logWarningParam, logErrorParam, dbParamsMap);
		fail("no funciona");
	}
	
	@Test(expected = Exception.class)
	public void probar(boolean logToFileParam, boolean logToConsoleParam, boolean logToDatabaseParam, boolean logMessageParam, boolean logWarningParam, boolean logErrorParam, Map dbParamsMap, String messageText, boolean message, boolean warning, boolean error) throws Exception
	{
		demo = new Demo(logToFileParam, logToConsoleParam, logToDatabaseParam, logMessageParam, logWarningParam, logErrorParam, dbParamsMap);
		demo.LogMessage(messageText, message, warning, error);
		fail("no funciona");
	}

}
